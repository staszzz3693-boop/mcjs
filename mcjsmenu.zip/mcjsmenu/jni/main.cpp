// mcjsmenu: мод-меню с загрузкой .js скриптов для Minecraft PE 1.1.5 (armeabi-v7a)
// Хуки без inline-библиотек:
//   1) vtable LocalPlayer[31] = normalTick  -> тик игры, тут выполняется JS
//   2) GOT eglSwapBuffers                   -> рисуем меню
//   3) GOT AInputQueue_getEvent             -> тапы по меню
#include <jni.h>
#include <dlfcn.h>
#include <link.h>
#include <elf.h>
#include <sys/mman.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <ctype.h>
#include <stdint.h>
#include <stdlib.h>
#include <fcntl.h>
#include <math.h>
#include <pthread.h>
#include <string.h>
#include <stdio.h>
#include <android/log.h>
#include <android/input.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>

extern "C" {
#include "quickjs.h"
}

#define TAG "mcjsmenu"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
static const char* LIB = "libminecraftpe.so";
static const char* SCRIPT_DIR = "/sdcard/games/com.mojang/mcjs";

// ---------------------------------------------------------------- GOT / vtable
static bool unprotect(void* addr) {
    long ps = sysconf(_SC_PAGESIZE);
    uintptr_t p = (uintptr_t)addr & ~(ps - 1);
    return mprotect((void*)p, ps * 2, PROT_READ | PROT_WRITE) == 0;
}

struct ModInfo { uintptr_t base; const ElfW(Phdr)* ph; int n; };
static int phdrCb(struct dl_phdr_info* i, size_t, void* d) {
    if (i->dlpi_name && strstr(i->dlpi_name, LIB)) {
        ModInfo* m = (ModInfo*)d; m->base = i->dlpi_addr; m->ph = i->dlpi_phdr; m->n = i->dlpi_phnum; return 1;
    }
    return 0;
}

// Подменяет все GOT-записи символа sym в libminecraftpe.so. Возвращает оригинал.
static void* patchGot(const char* sym, void* newFn) {
    ModInfo m = {0, 0, 0};
    dl_iterate_phdr(phdrCb, &m);
    if (!m.base) return nullptr;
    const ElfW(Dyn)* dyn = nullptr;
    for (int i = 0; i < m.n; i++)
        if (m.ph[i].p_type == PT_DYNAMIC) dyn = (const ElfW(Dyn)*)(m.base + m.ph[i].p_vaddr);
    if (!dyn) return nullptr;
    uintptr_t jmprel = 0, rel = 0, symtab = 0, strtab = 0; size_t pltsz = 0, relsz = 0;
    auto fix = [&](uintptr_t v) { return v < m.base ? v + m.base : v; };  // разные линкеры по-разному
    for (; dyn->d_tag != DT_NULL; dyn++) {
        switch (dyn->d_tag) {
            case DT_JMPREL: jmprel = fix(dyn->d_un.d_ptr); break;
            case DT_PLTRELSZ: pltsz = dyn->d_un.d_val; break;
            case DT_REL: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELSZ: relsz = dyn->d_un.d_val; break;
            case DT_SYMTAB: symtab = fix(dyn->d_un.d_ptr); break;
            case DT_STRTAB: strtab = fix(dyn->d_un.d_ptr); break;
        }
    }
    void* orig = nullptr;
    auto scan = [&](uintptr_t tbl, size_t sz) {
        for (size_t i = 0; i < sz / sizeof(Elf32_Rel); i++) {
            const Elf32_Rel* r = (const Elf32_Rel*)tbl + i;
            unsigned t = ELF32_R_TYPE(r->r_info);
            if (t != R_ARM_JUMP_SLOT && t != R_ARM_GLOB_DAT && t != R_ARM_ABS32) continue;
            const Elf32_Sym* s = (const Elf32_Sym*)symtab + ELF32_R_SYM(r->r_info);
            if (strcmp((const char*)strtab + s->st_name, sym) != 0) continue;
            void** slot = (void**)(m.base + r->r_offset);
            if (!unprotect(slot)) continue;
            if (!orig) orig = *slot;
            *slot = newFn;
        }
    };
    if (jmprel) scan(jmprel, pltsz);
    if (rel) scan(rel, relsz);
    return orig;
}

// ---------------------------------------------------------------- игровое API
typedef void (*tick_t)(void*);
typedef void (*setpos_t)(void*, const float*);
typedef const float* (*getpos_t)(const void*);
typedef void (*jump_t)(void*);

static tick_t origTick;
static setpos_t gSetPos;
static getpos_t gGetPos;
static jump_t gJump;
static void* gPlayer;  // LocalPlayer*, обновляется каждый тик

// поиск существ и урон
typedef void* (*getregion_t)(const void*);                          // Entity::getRegion -> BlockSource*
typedef void** (*getents_t)(void*, void*, const float*);            // BlockSource::getEntities -> vector<Entity*>&
typedef void (*dmgctor_t)(void*, int);                              // EntityDamageSource(cause)
typedef bool (*hurt_t)(void*, const void*, int, bool, bool);        // Entity::hurt(src, dmg, knockback, ignoreArmor)
static getregion_t gGetRegion;
static getents_t gGetEnts;
static dmgctor_t gDmgCtor;
static hurt_t gHurt;

// ---------------------------------------------------------------- скрипты
struct Script {
    std::string name, path;
    bool wanted = false, active = false;
    std::vector<JSValue> ticks;
};
static std::vector<Script> gScripts;
static std::mutex gMx;
static bool gRescan = true;
static JSRuntime* gRt;
static JSContext* gCtx;
static int gCur = -1;  // индекс скрипта, который сейчас выполняется

static JSValue js_log(JSContext* c, JSValueConst, int argc, JSValueConst* argv) {
    for (int i = 0; i < argc; i++) {
        const char* s = JS_ToCString(c, argv[i]);
        if (s) { LOGI("[js] %s", s); JS_FreeCString(c, s); }
    }
    return JS_UNDEFINED;
}
static JSValue js_registerTick(JSContext* c, JSValueConst, int argc, JSValueConst* argv) {
    if (argc > 0 && JS_IsFunction(c, argv[0]) && gCur >= 0)
        gScripts[gCur].ticks.push_back(JS_DupValue(c, argv[0]));
    return JS_UNDEFINED;
}
static JSValue js_getPos(JSContext* c, JSValueConst, int, JSValueConst*) {
    JSValue a = JS_NewArray(c);
    if (gPlayer && gGetPos) {
        const float* p = gGetPos(gPlayer);
        for (int i = 0; i < 3; i++) JS_SetPropertyUint32(c, a, i, JS_NewFloat64(c, p[i]));
    }
    return a;
}
static JSValue js_setPos(JSContext* c, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 3 || !gPlayer || !gSetPos) return JS_UNDEFINED;
    double d[3];
    for (int i = 0; i < 3; i++) JS_ToFloat64(c, &d[i], argv[i]);
    float v[3] = {(float)d[0], (float)d[1], (float)d[2]};
    gSetPos(gPlayer, v);
    return JS_UNDEFINED;
}
static JSValue js_jump(JSContext*, JSValueConst, int, JSValueConst*) {
    if (gPlayer && gJump) gJump(gPlayer);
    return JS_UNDEFINED;
}

// world.damageNear(radius, damage[, cause]) -> число задетых существ
static JSValue js_damageNear(JSContext* c, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 2 || !gPlayer || !gGetPos || !gGetRegion || !gGetEnts || !gDmgCtor || !gHurt)
        return JS_NewInt32(c, -1);
    double r = 7, dmg = 1000; int32_t cause = 13;  // 13 = Void (урон мимо брони)
    JS_ToFloat64(c, &r, argv[0]); JS_ToFloat64(c, &dmg, argv[1]);
    if (argc > 2) JS_ToInt32(c, &cause, argv[2]);
    const float* pp = gGetPos(gPlayer);
    float px = pp[0], py = pp[1], pz = pp[2], fr = (float)r;
    void* region = gGetRegion(gPlayer);
    if (!region) return JS_NewInt32(c, -1);
    float box[8] = {px - fr, py - fr, pz - fr, px + fr, py + fr, pz + fr, 0, 0};
    void** vec = gGetEnts(region, gPlayer, box);
    if (!vec) return JS_NewInt32(c, -1);
    void** b = (void**)vec[0]; void** e = (void**)vec[1];   // begin/end вектора
    if (e < b || (e - b) > 512) { LOGI("damageNear: bad vector"); return JS_NewInt32(c, -1); }
    void* list[512]; int n = 0;
    for (void** it = b; it != e; ++it) list[n++] = *it;       // копия: урон может менять список
    alignas(8) char src[64]; memset(src, 0, sizeof src);
    gDmgCtor(src, cause);
    int hit = 0;
    for (int i = 0; i < n; i++) {
        void* en = list[i];
        if (!en || en == gPlayer) continue;
        const float* q = gGetPos(en);
        float dx = q[0] - px, dy = q[1] - py, dz = q[2] - pz;
        if (dx * dx + dy * dy + dz * dz > fr * fr) continue;
        gHurt(en, src, (int)dmg, false, true);
        hit++;
    }
    return JS_NewInt32(c, hit);
}


// ================================================================ native: универсальный доступ к игре
static int gPipe[2] = {-1, -1};
static uint32_t U32(JSContext* c, JSValueConst v) { double d = 0; JS_ToFloat64(c, &d, v); return (uint32_t)(int64_t)d; }
static bool readable(uint32_t a, size_t n) {  // проверка памяти через pipe: ошибка EFAULT вместо краша
    if (gPipe[0] < 0) { if (pipe(gPipe)) return false; fcntl(gPipe[0], F_SETFL, O_NONBLOCK); fcntl(gPipe[1], F_SETFL, O_NONBLOCK); }
    if (!a || n > 4096) return false;
    ssize_t w = write(gPipe[1], (void*)a, n);
    if (w < 0) return false;
    char tmp[4096]; while (read(gPipe[0], tmp, sizeof tmp) > 0) {}
    return true;
}
#define NEED(c, a, n) if (!readable((a), (n))) return JS_ThrowRangeError(c, "bad memory address 0x%x", (unsigned)(a))

static JSValue n_sym(JSContext* c, JSValueConst, int, JSValueConst* argv) {
    const char* s = JS_ToCString(c, argv[0]); if (!s) return JS_NewUint32(c, 0);
    void* h = dlopen(LIB, RTLD_NOW | RTLD_NOLOAD);
    void* a = h ? dlsym(h, s) : nullptr;
    JS_FreeCString(c, s);
    return JS_NewUint32(c, (uint32_t)(uintptr_t)a);
}
typedef uint32_t (*fn12_t)(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
static JSValue n_call(JSContext* c, JSValueConst, int argc, JSValueConst* argv) {
    uint32_t addr = U32(c, argv[0]), a[12] = {0};
    if (!addr) return JS_ThrowReferenceError(c, "call: null function address");
    if (argc > 1) {
        JSValue lv = JS_GetPropertyStr(c, argv[1], "length"); int32_t len = 0; JS_ToInt32(c, &len, lv); JS_FreeValue(c, lv);
        for (int i = 0; i < len && i < 12; i++) { JSValue v = JS_GetPropertyUint32(c, argv[1], i); a[i] = U32(c, v); JS_FreeValue(c, v); }
    }
    uint32_t r = ((fn12_t)addr)(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
    return JS_NewUint32(c, r);
}
static JSValue n_readU32(JSContext* c, JSValueConst, int, JSValueConst* v) { uint32_t a = U32(c, v[0]); NEED(c, a, 4); return JS_NewUint32(c, *(uint32_t*)a); }
static JSValue n_readU8(JSContext* c, JSValueConst, int, JSValueConst* v) { uint32_t a = U32(c, v[0]); NEED(c, a, 1); return JS_NewUint32(c, *(uint8_t*)a); }
static JSValue n_readF32(JSContext* c, JSValueConst, int, JSValueConst* v) { uint32_t a = U32(c, v[0]); NEED(c, a, 4); return JS_NewFloat64(c, *(float*)a); }
static JSValue n_writeU32(JSContext* c, JSValueConst, int, JSValueConst* v) { uint32_t a = U32(c, v[0]); NEED(c, a, 4); *(uint32_t*)a = U32(c, v[1]); return JS_UNDEFINED; }
static JSValue n_writeU8(JSContext* c, JSValueConst, int, JSValueConst* v) { uint32_t a = U32(c, v[0]); NEED(c, a, 1); *(uint8_t*)a = (uint8_t)U32(c, v[1]); return JS_UNDEFINED; }
static JSValue n_writeF32(JSContext* c, JSValueConst, int, JSValueConst* v) { uint32_t a = U32(c, v[0]); NEED(c, a, 4); double d = 0; JS_ToFloat64(c, &d, v[1]); *(float*)a = (float)d; return JS_UNDEFINED; }
static JSValue n_readStr(JSContext* c, JSValueConst, int, JSValueConst* v) {
    uint32_t a = U32(c, v[0]); std::string s;
    for (int i = 0; i < 4096; i++) { NEED(c, a + i, 1); char ch = *(char*)(a + i); if (!ch) break; s += ch; }
    return JS_NewStringLen(c, s.data(), s.size());
}
static JSValue n_alloc(JSContext* c, JSValueConst, int, JSValueConst* v) { return JS_NewUint32(c, (uint32_t)(uintptr_t)calloc(1, U32(c, v[0]) + 16)); }
static JSValue n_free(JSContext* c, JSValueConst, int, JSValueConst* v) { free((void*)(uintptr_t)U32(c, v[0])); return JS_UNDEFINED; }
static JSValue n_unprotect(JSContext* c, JSValueConst, int, JSValueConst* v) { return JS_NewBool(c, unprotect((void*)(uintptr_t)U32(c, v[0]))); }
static JSValue n_player(JSContext* c, JSValueConst, int, JSValueConst*) { return JS_NewUint32(c, (uint32_t)(uintptr_t)gPlayer); }
static JSValue n_f2i(JSContext* c, JSValueConst, int, JSValueConst* v) { double d = 0; JS_ToFloat64(c, &d, v[0]); float f = (float)d; uint32_t u; memcpy(&u, &f, 4); return JS_NewUint32(c, u); }
static JSValue n_i2f(JSContext* c, JSValueConst, int, JSValueConst* v) { uint32_t u = U32(c, v[0]); float f; memcpy(&f, &u, 4); return JS_NewFloat64(c, f); }
// std::string (gnustl COW) для функций, принимающих const std::string&. Возвращает адрес объекта-строки.
static JSValue n_newString(JSContext* c, JSValueConst, int, JSValueConst* v) {
    size_t n; const char* s = JS_ToCStringLen(c, &n, v[0]); if (!s) return JS_NewUint32(c, 0);
    uint32_t* rep = (uint32_t*)calloc(1, 12 + n + 1 + 16);   // {length, capacity, refcount} + chars
    rep[0] = (uint32_t)n; rep[1] = (uint32_t)n; rep[2] = 0x40000000;  // огромный refcount: игра не освободит нашу память
    memcpy((char*)(rep + 3), s, n); JS_FreeCString(c, s);
    uint32_t* obj = (uint32_t*)calloc(1, 16); obj[0] = (uint32_t)(uintptr_t)(rep + 3);
    return JS_NewUint32(c, (uint32_t)(uintptr_t)obj);
}
// поиск экспортированных символов игры по подстроке (для исследования API)
static JSValue n_findSym(JSContext* c, JSValueConst, int argc, JSValueConst* v) {
    const char* q = JS_ToCString(c, v[0]); if (!q) return JS_NewArray(c);
    int32_t maxn = 50; if (argc > 1) JS_ToInt32(c, &maxn, v[1]);
    JSValue arr = JS_NewArray(c);
    ModInfo m = {0, 0, 0}; dl_iterate_phdr(phdrCb, &m);
    if (m.base) {
        const ElfW(Dyn)* dyn = nullptr;
        for (int i = 0; i < m.n; i++) if (m.ph[i].p_type == PT_DYNAMIC) dyn = (const ElfW(Dyn)*)(m.base + m.ph[i].p_vaddr);
        uintptr_t symtab = 0, strtab = 0, hash = 0;
        auto fix = [&](uintptr_t x) { return x < m.base ? x + m.base : x; };
        for (; dyn && dyn->d_tag != DT_NULL; dyn++) {
            if (dyn->d_tag == DT_SYMTAB) symtab = fix(dyn->d_un.d_ptr);
            if (dyn->d_tag == DT_STRTAB) strtab = fix(dyn->d_un.d_ptr);
            if (dyn->d_tag == DT_HASH) hash = fix(dyn->d_un.d_ptr);
        }
        if (symtab && strtab && hash) {
            uint32_t nsym = ((uint32_t*)hash)[1]; int k = 0;
            for (uint32_t i = 0; i < nsym && k < maxn; i++) {
                const Elf32_Sym* sy = (const Elf32_Sym*)symtab + i;
                if (!sy->st_shndx) continue;
                const char* nm = (const char*)strtab + sy->st_name;
                if (strstr(nm, q)) JS_SetPropertyUint32(c, arr, k++, JS_NewString(c, nm));
            }
        }
    }
    JS_FreeCString(c, q);
    return arr;
}

static const char* PRELUDE = R"JS(
(function(){
var N=native, S={};
function fn(n){var a=S[n];if(!a){a=N.sym(n);if(!a)throw new Error("symbol not found: "+n);S[n]=a;}return a;}
function F(x){return N.f2i(x);}
function vec3(p){return [N.readF32(p),N.readF32(p+4),N.readF32(p+8)];}
function mkv3(x,y,z){var v=N.alloc(12);N.writeF32(v,x);N.writeF32(v+4,y);N.writeF32(v+8,z);return v;}
N.vcall=function(o,slot,args){var vt=N.readU32(o);return N.call(N.readU32(vt+slot*4),[o].concat(args||[]));};
globalThis.fn=fn;
globalThis.call=function(name,args){return N.call(fn(name),args||[]);};
globalThis.F=F; globalThis.I2F=N.i2f;
var E={
 getPos:function(e){return vec3(N.call(fn("_ZNK6Entity6getPosEv"),[e]));},
 setPos:function(e,x,y,z){var v=mkv3(x,y,z);N.call(fn("_ZN6Entity6setPosERK4Vec3"),[e,v]);N.free(v);},
 getVelocity:function(e){return vec3(N.call(fn("_ZNK6Entity11getVelocityEv"),[e]));},
 setMotion:function(e,x,y,z){var v=mkv3(x,y,z);N.call(fn("_ZN6Entity10lerpMotionERK4Vec3"),[e,v]);N.free(v);},
 setOnFire:function(e,sec){N.call(fn("_ZN6Entity9setOnFireEi"),[e,sec]);},
 isSneaking:function(e){return N.call(fn("_ZNK6Entity10isSneakingEv"),[e])&1;},
 getHealth:function(e){return N.call(fn("_ZNK3Mob9getHealthEv"),[e])|0;},
 getMaxHealth:function(e){return N.call(fn("_ZNK3Mob12getMaxHealthEv"),[e])|0;},
 setSpeed:function(e,v){N.call(fn("_ZN3Mob8setSpeedEf"),[e,F(v)]);},
 getRegion:function(e){return N.call(fn("_ZNK6Entity9getRegionEv"),[e]);},
 getLevel:function(e){return N.call(fn("_ZNK6Entity8getLevelEv"),[e]);},
 hurt:function(e,dmg,cause){var s=N.alloc(64);N.call(fn("_ZN18EntityDamageSourceC1E17EntityDamageCause"),[s,cause===undefined?13:cause]);var r=N.call(fn("_ZN6Entity4hurtERK18EntityDamageSourceibb"),[e,s,dmg,0,1])&1;N.free(s);return r;},
 remove:function(e){N.call(fn("_ZN6Entity6removeEv"),[e]);},
 isRemoved:function(e){return N.call(fn("_ZNK6Entity9isRemovedEv"),[e])&1;}
};
globalThis.Entity=E;
globalThis.me=function(){return N.player();};
var W=world;
W.region=function(){return E.getRegion(N.player());};
W.getBlock=function(x,y,z){return N.call(fn("_ZN11BlockSource10getBlockIDEiii"),[W.region(),x|0,y|0,z|0])&255;};
W.getData=function(x,y,z){return N.call(fn("_ZN11BlockSource7getDataEiii"),[W.region(),x|0,y|0,z|0])&255;};
W.setBlock=function(x,y,z,id,data){return N.call(fn("_ZN11BlockSource8setBlockEiii7BlockIDi"),[W.region(),x|0,y|0,z|0,id&255,data|0])&1;};
W.getTime=function(){return N.call(fn("_ZNK5Level7getTimeEv"),[E.getLevel(N.player())])|0;};
W.setTime=function(t){N.call(fn("_ZN5Level7setTimeEi"),[E.getLevel(N.player()),t|0]);};
W.entitiesNear=function(r){
 var p=N.player(),pos=E.getPos(p),box=N.alloc(32),out=[];
 var b=[pos[0]-r,pos[1]-r,pos[2]-r,pos[0]+r,pos[1]+r,pos[2]+r];
 for(var i=0;i<6;i++)N.writeF32(box+i*4,b[i]);
 var v=N.call(fn("_ZN11BlockSource11getEntitiesEP6EntityRK4AABB"),[W.region(),p,box]);
 var s=N.readU32(v),e=N.readU32(v+4);
 if(e>=s&&(e-s)/4<=512){for(var a=s;a<e;a+=4){var en=N.readU32(a);if(!en||en===p)continue;var q=E.getPos(en);var dx=q[0]-pos[0],dy=q[1]-pos[1],dz=q[2]-pos[2];if(dx*dx+dy*dy+dz*dz<=r*r)out.push(en);}}
 N.free(box);return out;
};
})();
)JS";

static void reportError();
static void initJs() {
    gRt = JS_NewRuntime();
    gCtx = JS_NewContext(gRt);
    JSValue g = JS_GetGlobalObject(gCtx);
    JS_SetPropertyStr(gCtx, g, "log", JS_NewCFunction(gCtx, js_log, "log", 1));
    JS_SetPropertyStr(gCtx, g, "registerTick", JS_NewCFunction(gCtx, js_registerTick, "registerTick", 1));
    JSValue pl = JS_NewObject(gCtx);
    JS_SetPropertyStr(gCtx, pl, "getPos", JS_NewCFunction(gCtx, js_getPos, "getPos", 0));
    JS_SetPropertyStr(gCtx, pl, "setPos", JS_NewCFunction(gCtx, js_setPos, "setPos", 3));
    JS_SetPropertyStr(gCtx, pl, "jump", JS_NewCFunction(gCtx, js_jump, "jump", 0));
    JS_SetPropertyStr(gCtx, g, "player", pl);
    JSValue wo = JS_NewObject(gCtx);
    JS_SetPropertyStr(gCtx, wo, "damageNear", JS_NewCFunction(gCtx, js_damageNear, "damageNear", 3));
    JS_SetPropertyStr(gCtx, g, "world", wo);
    JSValue nat = JS_NewObject(gCtx);
#define REG(name, f, n) JS_SetPropertyStr(gCtx, nat, name, JS_NewCFunction(gCtx, f, name, n))
    REG("sym", n_sym, 1); REG("call", n_call, 2); REG("readU32", n_readU32, 1); REG("readU8", n_readU8, 1);
    REG("readF32", n_readF32, 1); REG("writeU32", n_writeU32, 2); REG("writeU8", n_writeU8, 2); REG("writeF32", n_writeF32, 2);
    REG("readStr", n_readStr, 1); REG("alloc", n_alloc, 1); REG("free", n_free, 1); REG("unprotect", n_unprotect, 1);
    REG("player", n_player, 0); REG("f2i", n_f2i, 1); REG("i2f", n_i2f, 1); REG("newString", n_newString, 1);
    REG("findSym", n_findSym, 2);
    JS_SetPropertyStr(gCtx, g, "native", nat);
    JS_FreeValue(gCtx, g);
    JSValue pr = JS_Eval(gCtx, PRELUDE, strlen(PRELUDE), "<prelude>", JS_EVAL_TYPE_GLOBAL);
    if (JS_IsException(pr)) reportError();
    JS_FreeValue(gCtx, pr);
}

static void reportError() {
    JSValue e = JS_GetException(gCtx);
    const char* s = JS_ToCString(gCtx, e);
    LOGI("[js error] %s", s ? s : "?");
    if (s) JS_FreeCString(gCtx, s);
    JS_FreeValue(gCtx, e);
}

static void rescan() {  // gMx захвачен
    mkdir(SCRIPT_DIR, 0777);
    std::vector<Script> fresh;
    if (DIR* d = opendir(SCRIPT_DIR)) {
        while (dirent* e = readdir(d)) {
            std::string n = e->d_name;
            if (n.size() > 3 && n.substr(n.size() - 3) == ".js") {
                Script s; s.name = n; s.path = std::string(SCRIPT_DIR) + "/" + n;
                for (auto& o : gScripts) if (o.name == n) { s = o; break; }
                fresh.push_back(s);
            }
        }
        closedir(d);
    }
    for (auto& o : gScripts) {  // выгрузить пропавшие/перезагрузить
        bool keep = false; for (auto& f : fresh) if (f.name == o.name) keep = true;
        if (!keep) for (auto& v : o.ticks) JS_FreeValue(gCtx, v);
    }
    std::sort(fresh.begin(), fresh.end(), [](const Script& a, const Script& b) { return a.name < b.name; });
    gScripts.swap(fresh);
}

static void loadScript(int i) {
    Script& s = gScripts[i];
    FILE* f = fopen(s.path.c_str(), "rb");
    if (!f) { LOGI("cannot open %s", s.path.c_str()); s.wanted = false; return; }
    std::string src; char buf[4096]; size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) src.append(buf, n);
    fclose(f);
    gCur = i;
    JSValue r = JS_Eval(gCtx, src.c_str(), src.size(), s.name.c_str(), JS_EVAL_TYPE_GLOBAL);
    if (JS_IsException(r)) { reportError(); s.wanted = false; }
    else s.active = true;
    JS_FreeValue(gCtx, r);
    gCur = -1;
}
static void unloadScript(int i) {
    for (auto& v : gScripts[i].ticks) JS_FreeValue(gCtx, v);
    gScripts[i].ticks.clear();
    gScripts[i].active = false;
}

static void hookedTick(void* self) {
    origTick(self);
    gPlayer = self;
    std::lock_guard<std::mutex> lk(gMx);
    if (!gCtx) initJs();
    if (gRescan) { rescan(); gRescan = false; }
    for (size_t i = 0; i < gScripts.size(); i++) {
        Script& s = gScripts[i];
        if (s.wanted && !s.active) loadScript((int)i);
        else if (!s.wanted && s.active) unloadScript((int)i);
        if (!s.active) continue;
        gCur = (int)i;
        for (auto& fn : s.ticks) {
            JSValue r = JS_Call(gCtx, fn, JS_UNDEFINED, 0, nullptr);
            if (JS_IsException(r)) { reportError(); s.wanted = false; }
            JS_FreeValue(gCtx, r);
        }
        gCur = -1;
    }
}

// ---------------------------------------------------------------- GL оверлей
static const struct { char c; unsigned char b[5]; } FONT[] = {
 {'0',{0x3E,0x51,0x49,0x45,0x3E}},{'1',{0x00,0x42,0x7F,0x40,0x00}},{'2',{0x42,0x61,0x51,0x49,0x46}},
 {'3',{0x21,0x41,0x45,0x4B,0x31}},{'4',{0x18,0x14,0x12,0x7F,0x10}},{'5',{0x27,0x45,0x45,0x45,0x39}},
 {'6',{0x3C,0x4A,0x49,0x49,0x30}},{'7',{0x01,0x71,0x09,0x05,0x03}},{'8',{0x36,0x49,0x49,0x49,0x36}},
 {'9',{0x06,0x49,0x49,0x29,0x1E}},{'A',{0x7E,0x11,0x11,0x11,0x7E}},{'B',{0x7F,0x49,0x49,0x49,0x36}},
 {'C',{0x3E,0x41,0x41,0x41,0x22}},{'D',{0x7F,0x41,0x41,0x22,0x1C}},{'E',{0x7F,0x49,0x49,0x49,0x41}},
 {'F',{0x7F,0x09,0x09,0x09,0x01}},{'G',{0x3E,0x41,0x49,0x49,0x7A}},{'H',{0x7F,0x08,0x08,0x08,0x7F}},
 {'I',{0x00,0x41,0x7F,0x41,0x00}},{'J',{0x20,0x40,0x41,0x3F,0x01}},{'K',{0x7F,0x08,0x14,0x22,0x41}},
 {'L',{0x7F,0x40,0x40,0x40,0x40}},{'M',{0x7F,0x02,0x0C,0x02,0x7F}},{'N',{0x7F,0x04,0x08,0x10,0x7F}},
 {'O',{0x3E,0x41,0x41,0x41,0x3E}},{'P',{0x7F,0x09,0x09,0x09,0x06}},{'Q',{0x3E,0x41,0x51,0x21,0x5E}},
 {'R',{0x7F,0x09,0x19,0x29,0x46}},{'S',{0x46,0x49,0x49,0x49,0x31}},{'T',{0x01,0x01,0x7F,0x01,0x01}},
 {'U',{0x3F,0x40,0x40,0x40,0x3F}},{'V',{0x1F,0x20,0x40,0x20,0x1F}},{'W',{0x3F,0x40,0x38,0x40,0x3F}},
 {'X',{0x63,0x14,0x08,0x14,0x63}},{'Y',{0x07,0x08,0x70,0x08,0x07}},{'Z',{0x61,0x51,0x49,0x45,0x43}},
 {'.',{0x00,0x60,0x60,0x00,0x00}},{'-',{0x08,0x08,0x08,0x08,0x08}},{'_',{0x40,0x40,0x40,0x40,0x40}},
 {':',{0x00,0x36,0x36,0x00,0x00}},{'[',{0x00,0x7F,0x41,0x41,0x00}},{']',{0x00,0x41,0x41,0x7F,0x00}},
};

typedef EGLBoolean (*swap_t)(EGLDisplay, EGLSurface);
static swap_t origSwap;
static bool gOpen = false;
static int gW = 1, gH = 1;
static float gSc = 1;  // масштаб UI
static GLuint gProg; static GLint aPos, uScr, uCol;

static void initGL() {
    const char* vs = "attribute vec2 p;uniform vec2 s;void main(){gl_Position=vec4(p.x/s.x*2.-1.,1.-p.y/s.y*2.,0.,1.);}";
    const char* fs = "precision mediump float;uniform vec4 c;void main(){gl_FragColor=c;}";
    GLuint v = glCreateShader(GL_VERTEX_SHADER); glShaderSource(v, 1, &vs, 0); glCompileShader(v);
    GLuint f = glCreateShader(GL_FRAGMENT_SHADER); glShaderSource(f, 1, &fs, 0); glCompileShader(f);
    gProg = glCreateProgram(); glAttachShader(gProg, v); glAttachShader(gProg, f); glLinkProgram(gProg);
    aPos = glGetAttribLocation(gProg, "p"); uScr = glGetUniformLocation(gProg, "s"); uCol = glGetUniformLocation(gProg, "c");
}

static std::vector<float> gBatch;
static void quad(float x, float y, float w, float h) {
    float v[12] = {x,y, x+w,y, x,y+h, x+w,y, x+w,y+h, x,y+h};
    gBatch.insert(gBatch.end(), v, v + 12);
}
static void flush(float r, float g, float b, float a) {
    if (gBatch.empty()) return;
    glUniform4f(uCol, r, g, b, a);
    glVertexAttribPointer(aPos, 2, GL_FLOAT, GL_FALSE, 0, gBatch.data());
    glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(gBatch.size() / 2));
    gBatch.clear();
}
static void text(const std::string& s, float x, float y, float px) {
    for (char ch : s) {
        ch = (char)toupper((unsigned char)ch);
        for (auto& g : FONT) if (g.c == ch)
            for (int col = 0; col < 5; col++)
                for (int row = 0; row < 7; row++)
                    if (g.b[col] & (1 << row)) quad(x + col * px, y + row * px, px, px);
        x += 6 * px;
    }
}

// геометрия меню (в пикселях)
static float btnW() { return 56 * gSc; }
static float btnH() { return 28 * gSc; }
static float rowH() { return 28 * gSc; }
static float panW() { return 280 * gSc; }
static float panX() { return 10 * gSc; }
static float panY() { return 10 * gSc + btnH() + 4 * gSc; }

static void drawMenu() {
    float px = std::max(1.0f, 2.0f * gSc);
    quad(10 * gSc, 10 * gSc, btnW(), btnH()); flush(0.1f, 0.1f, 0.1f, 0.8f);
    text("JS", 10 * gSc + 8 * gSc, 10 * gSc + 6 * gSc, px); flush(1, 1, 1, 1);
    if (!gOpen) return;
    std::lock_guard<std::mutex> lk(gMx);
    int rows = 1 + (int)gScripts.size();
    quad(panX(), panY(), panW(), rows * rowH()); flush(0.05f, 0.05f, 0.05f, 0.85f);
    text("RELOAD LIST", panX() + 8 * gSc, panY() + 7 * gSc, px); flush(1, 0.9f, 0.3f, 1);
    for (size_t i = 0; i < gScripts.size(); i++) {
        float y = panY() + (i + 1) * rowH();
        text(std::string(gScripts[i].wanted ? "[X] " : "[ ] ") + gScripts[i].name, panX() + 8 * gSc, y + 7 * gSc, px);
        flush(gScripts[i].wanted ? 0.4f : 0.85f, gScripts[i].wanted ? 1.0f : 0.85f, gScripts[i].wanted ? 0.4f : 0.85f, 1);
    }
}

static EGLBoolean hookedSwap(EGLDisplay d, EGLSurface s) {
    eglQuerySurface(d, s, EGL_WIDTH, &gW); eglQuerySurface(d, s, EGL_HEIGHT, &gH);
    gSc = std::max(1.0f, gH / 360.0f);
    GLint prog, abuf, en, vp[4]; GLboolean blend = glIsEnabled(GL_BLEND), depth = glIsEnabled(GL_DEPTH_TEST),
        cull = glIsEnabled(GL_CULL_FACE), scis = glIsEnabled(GL_SCISSOR_TEST);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prog); glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &abuf);
    glGetIntegerv(GL_VIEWPORT, vp);
    if (!gProg) initGL();
    glUseProgram(gProg); glBindBuffer(GL_ARRAY_BUFFER, 0);
    glGetVertexAttribiv(aPos, GL_VERTEX_ATTRIB_ARRAY_ENABLED, &en);
    glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_SCISSOR_TEST);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glViewport(0, 0, gW, gH);
    glUniform2f(uScr, (float)gW, (float)gH);
    glEnableVertexAttribArray(aPos);
    drawMenu();
    if (!en) glDisableVertexAttribArray(aPos);
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    glBindBuffer(GL_ARRAY_BUFFER, abuf); glUseProgram(prog);
    if (!blend) glDisable(GL_BLEND); if (depth) glEnable(GL_DEPTH_TEST);
    if (cull) glEnable(GL_CULL_FACE); if (scis) glEnable(GL_SCISSOR_TEST);
    return origSwap(d, s);
}

// ---------------------------------------------------------------- ввод
typedef int32_t (*getev_t)(AInputQueue*, AInputEvent**);
static getev_t origGetEvent;
static bool gConsuming = false;

static bool handleTap(float x, float y) {
    float bx = 10 * gSc, by = 10 * gSc;
    if (x >= bx && x <= bx + btnW() && y >= by && y <= by + btnH()) { gOpen = !gOpen; return true; }
    if (!gOpen) return false;
    std::lock_guard<std::mutex> lk(gMx);
    int rows = 1 + (int)gScripts.size();
    if (x < panX() || x > panX() + panW() || y < panY() || y > panY() + rows * rowH()) return false;
    int row = (int)((y - panY()) / rowH());
    if (row == 0) gRescan = true;
    else { Script& s = gScripts[row - 1]; s.wanted = !s.wanted; }
    return true;
}

static int32_t hookedGetEvent(AInputQueue* q, AInputEvent** ev) {
    int32_t r = origGetEvent(q, ev);
    if (r < 0 || !*ev) return r;
    if (AInputEvent_getType(*ev) != AINPUT_EVENT_TYPE_MOTION) return r;
    int act = AMotionEvent_getAction(*ev) & AMOTION_EVENT_ACTION_MASK;
    float x = AMotionEvent_getX(*ev, 0), y = AMotionEvent_getY(*ev, 0);
    if (act == AMOTION_EVENT_ACTION_DOWN && handleTap(x, y)) gConsuming = true;
    if (gConsuming) {
        if (act == AMOTION_EVENT_ACTION_UP || act == AMOTION_EVENT_ACTION_CANCEL) gConsuming = false;
        AInputQueue_finishEvent(q, *ev, 1);
        return -1;  // событие съедено меню
    }
    return r;
}

// ---------------------------------------------------------------- установка хуков
static void* installThread(void*) {
    void* h = nullptr;
    for (int i = 0; i < 600 && !h; i++) { h = dlopen(LIB, RTLD_NOW | RTLD_NOLOAD); if (!h) usleep(100000); }
    if (!h) { LOGI("libminecraftpe.so not found"); return nullptr; }
    sleep(2);  // дать игре закончить релокации

    gSetPos = (setpos_t)dlsym(h, "_ZN6Entity6setPosERK4Vec3");
    gGetPos = (getpos_t)dlsym(h, "_ZNK6Entity6getPosEv");
    gJump = (jump_t)dlsym(h, "_ZN6Player14jumpFromGroundEv");
    gGetRegion = (getregion_t)dlsym(h, "_ZNK6Entity9getRegionEv");
    gGetEnts = (getents_t)dlsym(h, "_ZN11BlockSource11getEntitiesEP6EntityRK4AABB");
    gDmgCtor = (dmgctor_t)dlsym(h, "_ZN18EntityDamageSourceC1E17EntityDamageCause");
    gHurt = (hurt_t)dlsym(h, "_ZN6Entity4hurtERK18EntityDamageSourceibb");
    LOGI("api: region=%p ents=%p dmg=%p hurt=%p", gGetRegion, gGetEnts, gDmgCtor, gHurt);

    char* vt = (char*)dlsym(h, "_ZTV11LocalPlayer");
    if (vt) {
        // vtable[31] (normalTick) = _ZTV + 8 + 31*4. Проверено по релокациям: 0x236a9e4 - 0x236a960 = 0x84
        void** slot = (void**)(vt + 0x84);
        if (unprotect(slot)) { origTick = (tick_t)*slot; *slot = (void*)hookedTick; LOGI("tick hook ok"); }
    } else LOGI("_ZTV11LocalPlayer not found");

    origSwap = (swap_t)patchGot("eglSwapBuffers", (void*)hookedSwap);
    origGetEvent = (getev_t)patchGot("AInputQueue_getEvent", (void*)hookedGetEvent);
    LOGI("swap=%p input=%p", origSwap, origGetEvent);
    return nullptr;
}

__attribute__((constructor)) static void onLoad() {
    pthread_t t; pthread_create(&t, nullptr, installThread, nullptr); pthread_detach(t);
}

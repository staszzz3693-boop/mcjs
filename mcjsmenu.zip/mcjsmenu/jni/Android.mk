LOCAL_PATH := $(call my-dir)

# QuickJS: положите исходники в jni/quickjs (quickjs.c cutils.c libregexp.c libunicode.c + .h)
include $(CLEAR_VARS)
LOCAL_MODULE := mcjsmenu
LOCAL_SRC_FILES := main.cpp \
  quickjs/quickjs.c quickjs/cutils.c quickjs/libregexp.c quickjs/libunicode.c
# если у вашей версии QuickJS есть dtoa.c / libbf.c, добавьте их сюда
LOCAL_C_INCLUDES := $(LOCAL_PATH)/quickjs
LOCAL_CFLAGS := -O2 -D_GNU_SOURCE -DCONFIG_VERSION=\"mcjs\" -Wno-unused-parameter -Wno-sign-compare
LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv2 -ldl -lm
include $(BUILD_SHARED_LIBRARY)

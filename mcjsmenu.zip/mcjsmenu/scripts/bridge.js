// Мост: ставит стекло (id 20) под ногами игрока
registerTick(function () {
  var p = me(), pos = Entity.getPos(p);
  var x = Math.floor(pos[0]), y = Math.floor(pos[1]) - 2, z = Math.floor(pos[2]);
  if (world.getBlock(x, y, z) === 0) world.setBlock(x, y, z, 20, 0);
});

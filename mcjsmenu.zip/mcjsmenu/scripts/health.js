// Пример: вывод здоровья игрока и ближайших существ раз в 2 секунды
var t = 0;
registerTick(function () {
  if (++t % 40) return;
  log("my hp: " + Entity.getHealth(me()));
  var l = world.entitiesNear(10);
  for (var i = 0; i < l.length; i++) log("entity " + l[i].toString(16) + " hp=" + Entity.getHealth(l[i]));
});

// Поиск функций игры: результат смотрите в logcat (тег mcjsmenu). Меняйте строку поиска.
var list = native.findSym("Player", 40);
for (var i = 0; i < list.length; i++) log(list[i]);

// Всегда день
var t = 0;
registerTick(function () { if (++t % 100 === 0) world.setTime(1000); });

// Самопроверка мода. Результат виден в мире: перед вами на уровне головы появится ряд блоков.
// ЗЕЛЁНЫЙ блок = тест пройден, КРАСНЫЙ = провален. Слева золотой блок (начало ряда).
// Порядок слева направо: смотри список TESTS ниже. Также всё пишется в logcat (тег mcjsmenu).
// Если блоков нет совсем: скрипт не запустился (галочка в меню сбросилась) или хук тика не работает.
var GREEN = 5, RED = 14, WOOL = 35, GOLD = 41;
var done = false, ticks = 0;

var TESTS = [
  ["native-api", function () { return typeof native.call === "function" && typeof Entity.getPos === "function"; }],
  ["symbols", function () { return fn("_ZN6Entity6setPosERK4Vec3") !== 0 && fn("_ZNK6Entity6getPosEv") !== 0; }],
  ["player-ptr", function () { return me() !== 0; }],
  ["vtable", function () { return native.readU32(me()) === native.sym("_ZTV11LocalPlayer") + 8; }],
  ["getPos", function () { var p = Entity.getPos(me()); return isFinite(p[0]) && isFinite(p[1]) && isFinite(p[2]) && p[1] > -50 && p[1] < 400; }],
  ["memory", function () { var m = native.alloc(8); native.writeU32(m, 12345); native.writeF32(m + 4, 1.5); var ok = native.readU32(m) === 12345 && native.readF32(m + 4) === 1.5; native.free(m); return ok; }],
  ["float-convert", function () { return I2F(F(2.5)) === 2.5; }],
  ["getTime", function () { var t = world.getTime(); return typeof t === "number" && t >= 0; }],
  ["getBlock", function () { var p = Entity.getPos(me()); var id = world.getBlock(Math.floor(p[0]), Math.floor(p[1]) - 2, Math.floor(p[2])); return id >= 0 && id < 256; }],
  ["entities", function () { return Array.isArray(world.entitiesNear(10)); }],
  ["setBlock-readback", function () { var p = Entity.getPos(me()); var x = Math.floor(p[0]), y = Math.floor(p[1]) + 5, z = Math.floor(p[2]); world.setBlock(x, y, z, 1, 0); var ok = world.getBlock(x, y, z) === 1; world.setBlock(x, y, z, 0, 0); return ok; }]
];

registerTick(function () {
  ticks++;
  if (done || ticks < 40) return;   // подождать 2 секунды после включения
  done = true;
  var p;
  try { p = Entity.getPos(me()); } catch (e) { log("selftest: cannot read position: " + e); return; }
  var bx = Math.floor(p[0]), by = Math.floor(p[1]) + 1, bz = Math.floor(p[2]) + 3;
  world.setBlock(bx - 1, by, bz, GOLD, 0);
  var pass = 0;
  for (var i = 0; i < TESTS.length; i++) {
    var ok = false;
    try { ok = !!TESTS[i][1](); } catch (e) { log("selftest " + TESTS[i][0] + " error: " + e); }
    log("selftest " + (i + 1) + " " + TESTS[i][0] + ": " + (ok ? "OK" : "FAIL"));
    if (ok) pass++;
    world.setBlock(bx + i, by, bz, WOOL, ok ? GREEN : RED);
  }
  log("selftest: " + pass + "/" + TESTS.length + " passed");
  player.jump();   // подпрыгнет: значит хук тика и вызовы функций игры работают
});

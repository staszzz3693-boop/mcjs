// Авто-убийство мобов в радиусе. Игроков не трогает.
// Требует обновлённый libmcjsmenu.so (с native/Entity/world API).
var RADIUS = 7;      // радиус в блоках
var EVERY = 5;       // раз в сколько тиков бить (5 = 4 раза в секунду)
var DAMAGE = 1000;   // урон за удар
var FORCE_AFTER = 3; // если моб жив после стольких ударов, убрать его принудительно (0 = не убирать)

// Игроки определяются по таблицам виртуальных функций их классов
var PLAYER_VT = ["_ZTV6Player", "_ZTV11LocalPlayer", "_ZTV12RemotePlayer", "_ZTV12ServerPlayer"]
  .map(function (n) { return native.sym(n) + 8; });
// Мобы: у всех Mob в слоте 200 лежит Mob::hurtEffects (у предметов, стрел, лодок этого нет)
var MOB_FX = native.sym("_ZN3Mob11hurtEffectsERK18EntityDamageSourceibb");

function isPlayer(e) { return PLAYER_VT.indexOf(native.readU32(e)) >= 0; }
function isMob(e) {
  try { return native.readU32(native.readU32(e) + 200 * 4) === MOB_FX; }
  catch (x) { return false; }
}

var t = 0, hits = {};
registerTick(function () {
  if (++t % EVERY) return;
  var list = world.entitiesNear(RADIUS), seen = {};
  for (var i = 0; i < list.length; i++) {
    var e = list[i];
    if (isPlayer(e) || !isMob(e)) continue;
    seen[e] = 1;
    Entity.hurt(e, DAMAGE);
    hits[e] = (hits[e] || 0) + 1;
    if (FORCE_AFTER && hits[e] >= FORCE_AFTER) { Entity.remove(e); delete hits[e]; }
  }
  for (var k in hits) if (!seen[k]) delete hits[k];  // моб умер или ушёл
});
log("killaura: radius " + RADIUS + ", players are ignored");

// Убивает существ в радиусе 7 блоков (каждые 5 тиков = 4 раза в секунду)
var t = 0;
registerTick(function () {
  if (++t % 5 === 0) {
    var n = world.damageNear(7, 1000);
    if (n > 0) log("killed/hit: " + n);
  }
});

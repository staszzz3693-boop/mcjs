// /sdcard/games/com.mojang/mcjs/example.js
log("example.js loaded");
var n = 0;
registerTick(function () {
  n++;
  if (n % 20 === 0) {            // раз в секунду
    var p = player.getPos();
    log("pos " + p[0].toFixed(1) + " " + p[1].toFixed(1) + " " + p[2].toFixed(1));
  }
});

# API скриптов mcjsmenu (MCPE 1.1.5, ARM32)

Скрипты: обычные .js в /sdcard/games/com.mojang/mcjs/. Всё в logcat (тег mcjsmenu).
"Весь API игры" обёрнуть вручную нельзя (десятки тысяч функций), поэтому есть универсальный
слой: можно вызвать ЛЮБУЮ экспортированную функцию игры по имени символа.

## Основное
log(x)                      вывод в logcat
registerTick(fn)            fn вызывается каждый тик (20/с)
me()                        указатель на игрока (число)

## Entity (e = указатель на существо; для игрока me())
Entity.getPos(e) -> [x,y,z]        Entity.setPos(e,x,y,z)
Entity.getVelocity(e)              Entity.setMotion(e,x,y,z)
Entity.setOnFire(e,сек)            Entity.isSneaking(e)
Entity.getHealth(e)                Entity.getMaxHealth(e)       (только Mob)
Entity.setSpeed(e,v)               Entity.hurt(e,урон,[причина=13])
Entity.remove(e)                   Entity.isRemoved(e)
Entity.getRegion(e)                Entity.getLevel(e)

## world
world.getBlock(x,y,z) -> id        world.getData(x,y,z)
world.setBlock(x,y,z,id,data)      world.getTime() / world.setTime(t)
world.entitiesNear(радиус) -> [указатели]
world.damageNear(радиус,урон[,причина]) -> сколько задето (нативная, быстрая)

## player (старый API)
player.getPos() player.setPos(x,y,z) player.jump()

## Универсальный слой: вызов любой функции игры
fn("_ZN6Player14jumpFromGroundEv")       адрес функции по имени символа
call(имя, [арги])                        вызов; арги это числа (this первым для методов)
native.call(адрес, [арги])               то же по адресу, до 12 аргументов
native.vcall(объект, слот, [арги])       вызов виртуальной функции через vtable
F(1.5) / I2F(бит)                        float -> 32 бита и обратно (floats передаются как биты)
native.findSym("подстрока", макс)        поиск имён функций в игре
native.alloc(n) native.free(p)           своя память
native.readU8/U32/F32(адрес)  native.writeU8/U32/F32(адрес, знач)   (чтение проверяется, краша нет)
native.readStr(адрес)                    строка C
native.newString("текст")                создаёт std::string (gnustl); передавайте адрес как const std::string&
native.unprotect(адрес)                  сделать страницу записываемой

Правила вызова (ARM32, softfp): методы получают this первым аргументом; int/указатели/bool это числа;
float передавать как F(x); const Vec3& это указатель на 3 float в памяти (alloc + writeF32);
64-битные значения не поддерживаются. Неверный адрес или аргументы могут уронить игру.

## Как найти нужную функцию
1. native.findSym("Mob", 100) выводит имена функций; имя читается как C++ (_ZN3Mob8setSpeedEf = Mob::setSpeed(float)).
2. Нужен this: для игрока me(), для мобов world.entitiesNear().
3. Вызов: call("_ZN3Mob8setSpeedEf", [me(), F(0.2)]).
Таблицу виртуальных функций (vtable) можно читать так: native.readU32(native.sym("_ZTV11LocalPlayer")+8+слот*4).

## Известные имена (проверены в вашей libminecraftpe.so)
Entity::getPos/setPos(Vec3)/lerpMotion/getVelocity/setOnFire(int)/hurt(src,int,bool,bool)/remove/getRegion/getLevel
Mob::getHealth/getMaxHealth/setSpeed(float)     Level::getTime/setTime(int)
BlockSource::getBlockID(x,y,z)/getData(x,y,z)/setBlock(x,y,z,BlockID,int)/getEntities(Entity*,AABB)
Abilities::getAbility(string)/setAbility(string,bool/float)   Player::jumpFromGround
ChatScreenController::_handleChatMessage(string)  MinecraftScreenModel::sendChatMessage(string)
Первые два набора реально используются в API выше. Остальное вызывайте через call().
Ограничение: чтобы вызвать метод с объектом (например Abilities), нужен указатель на этот объект; ищите его
по смещению от Player (читать через native.readU32) или через функции-геттеры из findSym.
